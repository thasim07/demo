package polymorphismdemo;

//Runtime polymorphism or method overriding

//methods have same name and same parameter 

//this can be achieved with the help of extends

//methods will be overrided based on the object of the class

public class Sonhouse extends Fatherhouse{
	
	public void audicar()
	
	{
		System.out.println("this is son audi car");
	}
	
	public void bmwcar() {
		
		System.out.println("this is son bmw car");
	}
	
	public static void main(String[] args) {
		
		Sonhouse s= new Sonhouse();
		s.audicar();
		s.bmwcar();
		
		
	}
	
}
