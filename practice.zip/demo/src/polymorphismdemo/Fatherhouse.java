package polymorphismdemo;

public class Fatherhouse {

	public void bmwcar()
	{
		System.out.println("this is father bmw car");
	}
}
