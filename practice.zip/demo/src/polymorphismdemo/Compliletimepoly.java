package polymorphismdemo;

// compile time poly-morphism or method overloading

// more than one method will have same name but difference in parameter

//the difference may be number of parameter or datatype of the parameter or order of the datatype


public class Compliletimepoly {
	
	int a =10;
	int b =20;

	public void addnumbers()
	
	{
		System.out.println("Addition of two numbers: "+(a+b));
	}
	
	public void addnumbers(int a, int b) {
		
		System.out.println("Addition of two int:" + (a+b));
	}
	
	public void addnumbers(int a, double b) {
		
		System.out.println("Addition of one int and one double:" + (a+b));
	}
	
    public void addnumbers(double a, double b) {
		
		System.out.println("Addition of two double:" + (a+b));
	}
	
	public static void main(String[] args) {
		
		Compliletimepoly c= new Compliletimepoly();
		c.addnumbers();
		c.addnumbers(10, 10);
		c.addnumbers(30, 20.3);
		c.addnumbers(10.0,10.1);
	}
}
