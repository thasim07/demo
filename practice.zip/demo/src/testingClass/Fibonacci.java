package testingClass;

import java.util.Scanner;

public class Fibonacci {

	public static void main2(String[] args) 
	{
		int num1=0;
		int num2=1,num3,i,count=20;
		
		System.out.print(num1+" "+num2);
		
		for(i=2;i<count;i++)
		{
			num3=num1+num2;
			System.out.print(" "+num3);
			num1=num2;
			num2=num3;
		}
			
	}
	
	public static void main1(String[] args){

		String str="Ramesh suresh";
		StringBuilder str2=new StringBuilder();
		str2.append(str);
		str2=str2.reverse();
		System.out.println(str2);

		}
	
	public static void main(String[]args) {
		String s1;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a String: ");
	    s1=s.nextLine();
		char[]c=s1.toCharArray();
		
		for(int i=c.length-1;i>=0;i--) {
		
			System.out.print(c[i]);
			
		}
	}
}

