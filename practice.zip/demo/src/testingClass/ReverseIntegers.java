
package testingClass;

public class ReverseIntegers {
	public static void main(String[] args) {
		int[] numbers = {21, 34, 54, 89};

		for (int i = 0; i < numbers.length; i++) {
			int reversed = reverseInteger(numbers[i]);
			System.out.println("Reversed integer for " + numbers[i] + ": "+reversed);
		}
	}

	public static int reverseInteger(int number) {
		String numberString = Integer.toString(number);
		String reversedString = new StringBuilder(numberString).reverse().toString();
		return Integer.parseInt(reversedString);
	}
}
