package testingClass;

public class Duplicatecharacters {

	
	public static void main(String[]args) {
		
		String str=new String("dummada");
		int count=0,i,j;
		char[]c=str.toCharArray();
		System.out.println("Duplicate characters are:");
		for(i=0;i<str.length();i++) {
			for(j=i+1;j<str.length();j++) {
				
				if(c[i]==c[j]) {
					
					System.out.println(c[j]);
					
					count++;
					break;
				}
			}
		}
		
		
	}
}
