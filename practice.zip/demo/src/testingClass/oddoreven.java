package testingClass;

import java.util.Scanner;

public class oddoreven {
	
public static void main(String[]args) {
	
	int i=10;

	if(i%2==0) {
		
		System.out.println("It is even number");
	}
	else
	{
		System.out.println("It is odd number");
	}
}
}