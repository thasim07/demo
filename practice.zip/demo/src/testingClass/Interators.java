package testingClass;

import java.util.ArrayList;
import java.util.Iterator;

public class Interators {

	public static void main(String[]args) {
		
		ArrayList<Object> a=new ArrayList<Object>();
		a.add("rumaisa");
		a.add("Arshaq");
		a.add("Ramesh");
		a.add("Suresh");
		a.add(20);
		
		System.out.println(a.get(4));
		System.out.println(a.size());
		
		System.out.println("Using Iterator");
		Iterator<Object> i = a.iterator();
		while(i.hasNext()) {
			
			System.out.println(i.next());
		}
		
		System.out.println("Enhanced for loop");
		for(Object k:a) {
			
			System.out.println(k);
		}
		
		
		System.out.println("for loop:-----");
		for(int j=0;j<a.size();j++) {
			
			System.out.println(a.get(j));
			
			
		}
		
		System.out.println("Lambda Expression:----");
		
		a.forEach(k -> System.out.println(k));
		
		
	}
}
