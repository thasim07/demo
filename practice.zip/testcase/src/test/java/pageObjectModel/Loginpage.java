package pageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Loginpage {

	public static WebElement link(WebDriver driver) {

		return driver.findElement(By.linkText("destination of the week! The Beach!"));
	}

	public static WebElement departurecity(WebDriver driver) {

		return driver.findElement(By.xpath("//select[@class='form-inline' and @name='fromPort'] "));
		 
	}

	public static WebElement destinationcity(WebDriver driver) {
		 WebElement e1 = driver.findElement(By.xpath("//select[@class='form-inline' and @name='toPort'] "));
		 return e1;
	}
}
