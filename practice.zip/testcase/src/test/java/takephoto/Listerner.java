package takephoto;

import org.testng.ITestListener;
import org.testng.ITestResult;

public class Listerner extends Baseclass implements ITestListener{

	//@Override
	//public void onTestFailure(ITestResult result) {
		
	//	capturescreenshots(result.getName()+".jpg");
	//}

	@Override
	public void onTestSuccess(ITestResult result) {
		
		capturescreenshots(result.getName()+".jpg");
	}
	
	

}
