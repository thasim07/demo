package takephoto;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Testclass extends Baseclass {

	@Test

	public void myntra() throws Exception {

		driver.get("https://www.myntra.com/");
		driver.findElement(By.linkText("Men")).click();
		WebElement shoe = driver.findElement(By.xpath("//input[@placeholder='Search for products, brands and more']"));
		shoe.sendKeys("shoe for men");
		shoe.sendKeys(Keys.ENTER);
		
		/*String parentwindow = driver.getWindowHandle();
		driver.findElement(By.xpath("//picture[@class='img-responsive']/child::img[@title='ASIAN Men White Mesh Running Non-Marking Shoes']")).click();
		
		Set<String> windowHandles = driver.getWindowHandles();
		
		for(String childwindow:windowHandles) {
			
			if(!childwindow.equals(parentwindow)) {
				
				driver.switchTo().window(childwindow);
				driver.findElement(By.xpath("//p[text()=10]")).click();
				
				driver.findElement(By.xpath("//span[text()='WISHLIST']/preceding-sibling::span")).click();
				
			}
			
		}
		
		driver.switchTo().window(parentwindow);
		*/
		
		
		

	}
}
