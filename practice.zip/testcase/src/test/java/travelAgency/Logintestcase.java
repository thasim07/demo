package travelAgency;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pageObjectModel.Loginpage;

public class Logintestcase {

	public static WebDriver driver;

	@BeforeTest
	public void openbrowser() {

		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://blazedemo.com/index.php");
	}

	@AfterTest

	public void closebrowser() {
		driver.quit();
	}

	@Test(priority=1)

	public void title() {

		String Expectedtitle="Welcome to the Simple Travel Agency!";
		String actualtitle = driver.getTitle();
		if(Expectedtitle.equals(actualtitle)) {

			System.out.println("Given title is correct");

		}
		else
		{
			System.out.println("Given title is in-correct");
		}
	}
	@Test(priority=2)

	public void login() {

		Loginpage.link(driver).click();
		String actualurl = driver.getCurrentUrl();
		Assert.assertTrue(actualurl.contains("vacation"));

		driver.navigate().back();
	}

	@Test(priority=3)
	public void purchaseticket(){
		
		Loginpage.departurecity(driver).click();
		Select s=new Select(e);
		s.selectByIndex(5);
		Loginpage.destinationcity(driver).click();
		Select s1=new Select(e1);
		s1.selectByIndex(2);

	}
}
