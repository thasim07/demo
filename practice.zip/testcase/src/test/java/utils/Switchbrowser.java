package utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Switchbrowser {
	
	public WebDriver driver;
	@BeforeMethod
	public void openbrowser() {
		
		WebDriverManager.chromedriver().setup();
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://signin.aws.amazon.com/signin?redirect_uri=https%3A%2F%2Fconsole.aws.amazon.com%2Fconsole%2Fhome%3Ffromtb%3Dtrue%26hashArgs%3D%2523%26isauthcode%3Dtrue%26nc2%3Dh_ct%26src%3Dheader-signin%26state%3DhashArgsFromTB_us-west-2_3b03986b25d3424c&client_id=arn%3Aaws%3Asignin%3A%3A%3Aconsole%2Fcanvas&forceMobileApp=0&code_challenge=q7sFcknoUoqvg_0ppGld_y2jPQwx3fWMgB66n-0Xv5g&code_challenge_method=SHA-256");
		
	}
	
	@Test
	public void webtotext() throws FileNotFoundException {
		
		WebElement e = driver.findElement(By.xpath("//b[@id='signin_head']"));
		String text = e.getText();
		System.out.println(text);
		
		/*try {
			FileOutputStream fo= new FileOutputStream("C:\\Users\\Admin\\Downloads\\demo.xlsx");
			XSSFWorkbook wb= new XSSFWorkbook();
			XSSFSheet sheet = wb.createSheet("thasim");
			XSSFRow row = sheet.createRow(0);
			XSSFCell cell = row.createCell(0);
			cell.setCellValue(text);
			
			wb.write(fo);
			wb.close();
			fo.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		
		try {
			//File f=new File("C:\\\\Users\\\\Admin\\\\Downloads\\\\demo.txt");
			BufferedWriter bf=new BufferedWriter(new FileWriter("C:\\\\\\\\Users\\\\\\\\Admin\\\\\\\\Downloads\\\\\\\\demo.txt"));
			bf.write(text);
			//f.close();
			bf.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	
	@AfterMethod
	public void closebrowser() {
		
		driver.quit();
	}
}