package utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Alert {
	
	public WebDriver driver;
	
	@BeforeTest

	public void openbrowser() {
		
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://letcode.in/alert");
		
	}
	
	@Test
	
	public void Alertdemo() throws Exception{
		
		WebElement e = driver.findElement(By.id("accept"));
		e.click();
		Thread.sleep(3000);
		org.openqa.selenium.Alert a=driver.switchTo().alert();
		Thread.sleep(3000);
		a.accept();
		
		driver.findElement(By.id("confirm")).click();
		Thread.sleep(3000);
		org.openqa.selenium.Alert a1=driver.switchTo().alert();
		Thread.sleep(3000);
		System.out.println(a1.getText());
		a1.dismiss();
		
		driver.findElement(By.id("prompt")).click();
	
		
		org.openqa.selenium.Alert a2=driver.switchTo().alert();
		
		a2.sendKeys("Mohamed Thasim");
		
		System.out.println(a2.getText());
		a2.accept();
		
		driver.findElement(By.id("modern")).click();
		
		driver.findElement(By.xpath("//button[@aria-label='close']")).click();
		
		
		
	}
	
	@AfterTest
	
	public void closebrowser() {
		
		driver.close();
	}
	
	
}
