package utils;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;


public class Dropdown {
	
	public WebDriver driver;
	
	@BeforeTest
	
	public void openbrowser() {
		
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://letcode.in/dropdowns");
		
	}
	
	@Test(priority=0)
	public void dropdown() throws InterruptedException {
		
		  
          WebElement e = driver.findElement(By.xpath("//select[@id='fruits']"));
          e.click();
          
          
          
          Select s=new Select(e);
          
          s.selectByVisibleText("Apple");     
          Thread.sleep(7000);
	}
     @Test(dependsOnMethods="dropdown")
     
          public void selectsuperhero() throws Exception{
          
          WebElement e1 = driver.findElement(By.xpath("//select[@id='superheros']"));
          
          Select s1=new Select(e1);
          s1.selectByValue("sm");
          s1.selectByIndex(0);
          boolean multiple = s1.isMultiple();
          System.out.println(multiple);
          List<WebElement> allSelectedOptions = s1.getAllSelectedOptions();
          for(WebElement v:allSelectedOptions) {
        	  
        	  System.out.println("Selected option:"+v.getText());
          }
          Thread.sleep(7000);
          
     }
     
     @Test(dependsOnMethods="selectsuperhero")
     
     public void printoptions() throws InterruptedException {
    	 
          WebElement list=driver.findElement(By.xpath("//select[@id='lang']"));
          list.click();
          Select s2=new Select(list);
          s2.selectByIndex(4);
          Thread.sleep(7000);
          List<WebElement>l1=s2.getOptions();
          for(WebElement k:l1) {
        	  System.out.println("options: "+k.getText());
          }
          
          WebElement u = driver.findElement(By.xpath("//select[@id='country']"));
          u.click();
          Select i=new Select(u);
          i.selectByValue("India");
          //i.selectByIndex(3);
          Thread.sleep(7000);
          WebElement f = i.getFirstSelectedOption();
          System.out.println(f.getText());
          
          
          }
          
         
	@AfterTest
	
	public void closebrowser() {
		
		driver.quit();
		
	}

}
