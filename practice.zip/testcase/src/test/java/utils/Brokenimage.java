package utils;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Brokenimage {

	public static void main(String []args) throws IOException {

		imagecheck();
	}
	public static void imagecheck() throws IOException  {

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://sourceforge.net/projects/orangehrm/");

		List<WebElement> images = driver.findElements(By.tagName("img"));
		System.out.println(images.size());

		for(WebElement image:images) {

			String imagesrc = image.getAttribute("src");

			try {
				URL url=new URL(imagesrc);
				URLConnection urlconnection = url.openConnection();
				HttpURLConnection http=(HttpURLConnection)urlconnection;
				http.setConnectTimeout(5000);
				http.connect();

				if(http.getResponseCode()==200) {

					System.out.println(imagesrc + ">>" + http.getResponseCode()+ ">>"+ http.getResponseMessage());
				}
				else
				{
					System.err.println(imagesrc + ">>" + http.getResponseCode()+ ">>"+ http.getResponseMessage());
				}	

				http.disconnect();
			} catch (Exception e) {
				System.err.print(imagesrc);
			} 
		}

		driver.quit();
	}

}
