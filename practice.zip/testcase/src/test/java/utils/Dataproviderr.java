package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class Dataproviderr {
	
	@DataProvider(name="orangehrm")
	public String[][] getdata() throws IOException {
		
		File excelfile=new File("./testdata/exceldemo.xlsx");
		FileInputStream fis=new FileInputStream(excelfile);
		XSSFWorkbook workbook=new XSSFWorkbook(fis); 
		XSSFSheet sheetAt = workbook.getSheetAt(0);
		int numberOfRows = sheetAt.getPhysicalNumberOfRows();
		int numberofcol = sheetAt.getRow(0).getLastCellNum();
		
		String[][] data=new String[numberOfRows-1][numberofcol];
		
		for(int i=0;i<numberOfRows-1;i++) {
			for(int j=0;j<numberofcol;j++) {
				DataFormatter df=new DataFormatter();
				data[i][j]=df.formatCellValue(sheetAt.getRow(i+1).getCell(j));
			}
		}
		workbook.close();
		fis.close();
		
		return data;
	}
	
}
	

