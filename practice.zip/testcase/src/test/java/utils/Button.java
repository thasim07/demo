package utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Button {

	public WebDriver driver;
	
	
	@BeforeMethod
	
	public void openbrowser() {
		
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://letcode.in/buttons");
	}
	
	@Test
	
	public void button() throws InterruptedException
	{
		driver.findElement(By.id("home")).click();
		driver.navigate().back();
		WebElement e1 = driver.findElement(By.id("position"));
		int x = e1.getLocation().getX();
		int y = e1.getLocation().getY();
		
		System.out.println("Print X value: " + x);
		System.out.println("Print Y value: " + y);
		
		WebElement e2 = driver.findElement(By.id("color"));
		System.out.println("color of the button: "+e2.getCssValue("background-color"));
		
		WebElement e3 = driver.findElement(By.id("property"));
		System.out.println("height and width: "+e3.getSize());
		
		boolean e4 = driver.findElement(By.id("isDisabled")).isEnabled();
		System.out.println("is enabled: "+e4);
		
		WebElement e5 = driver.findElement(By.xpath("//button[@id='isDisabled' and @class='button is-primary']"));
		
		Actions a=new Actions(driver);
		
		a.clickAndHold(e5).build().perform();
		
		Thread.sleep(7000);
		
		
	
	}
	
	
	@AfterMethod
	
	public void closebrowser()
	{
		driver.close();
	}
}
