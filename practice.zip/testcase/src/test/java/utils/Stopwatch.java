package utils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Stopwatch {
	
	public static WebDriver driver;
	
	@BeforeTest
	public void openbrowser() {
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://www.google.com/");
	}
	
	@Test
	public void stoptime() throws Exception {
		
		WebElement search = driver.findElement(By.name("q"));
		search.sendKeys("Stop watch online");
		search.sendKeys(Keys.ENTER);
		
		driver.findElement(By.xpath("//span[text()='Start']")).click();
		Thread.sleep(7000);
		driver.findElement(By.xpath("//span[text()='Stop']")).click();
		
		Thread.sleep(5000);
		
		List<WebElement> lists = driver.findElements(By.xpath("//div[contains(@style,'background-color')]/child::span[contains(@class, 'act-tim')]"));
		
		//String text = list.getText();
		
		
		for(WebElement list:lists) {
			
			String text = list.getText();
			//if(text.contains(text)) {
				System.out.println("Stop watch time is:"+text);
			//}
		}
		
		LocalDateTime myDateObj = LocalDateTime.now();
		System.out.println(myDateObj);
	
		
	}
	
	@AfterTest
	public void closebrowser() {
		
		driver.quit();
	}

}
