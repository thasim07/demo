package utils;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FlipKartdemo {
	
	public static WebDriver driver;

	@BeforeTest
	public void openbrowser() {
		
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	   driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	}
	
	@Test
	public void flipkartcred() throws InterruptedException {
		
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		jse.executeScript("window.location= 'https://getbootstrap.com/docs/4.0/components/dropdowns/'");
		Thread.sleep(5000);
		jse.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[@id='dropdownMenuButton']")).click();
		List<WebElement> e1 = driver.findElements(By.xpath("//div[@class='dropdown-menu show']/a"));
		//for(int i=0;i<e1.size();i++)
		//{
		//	System.out.println(e1.get(i).getText());
		//}
		
		//for(int i=0;i<e1.size();i++)
		//{
		//	WebElement e2 = e1.get(i);
		//	String txt = e2.getText();
		//	if(txt.equals("Action")) {
				
		//		System.out.println(txt);
		//	}
		//}
		
		for(WebElement k:e1)
		{
			String txt = k.getText();
			if(txt.equals("Another actionm")) {
				System.out.println(txt);
			}
		}
				System.out.print("Not equal");
			
		
		
		
		Thread.sleep(5000);
		
		//driver.get("https://chercher.tech/practice/practice-dropdowns-selenium-webdriver");
		//Thread.sleep(3000);
		//WebElement e = driver.findElement(By.xpath("//select[@id='first']"));
		//Select s=new Select(e);
		//Thread.sleep(3000);
		//s.selectByIndex(2);
		//Thread.sleep(3000);
		//s.selectByValue("Microsoft");
		//Thread.sleep(3000);
		//s.selectByVisibleText("Google");
		//Thread.sleep(3000);
		//boolean m = s.isMultiple();
		//System.out.println(m);
		//Thread.sleep(3000);
		//WebElement e1= driver.findElement(By.xpath("//select[@id='second']"));
		//Select s2=new Select(e1);
		//List<WebElement> list = s2.getOptions();
		//for(WebElement k : list)
		//{
		//	System.out.println(k.getText());
		//}
		//s2.selectByIndex(3);
		//Thread.sleep(3000);
		//s2.selectByValue("pizza");
		//Thread.sleep(3000);
		//WebElement e3 = s2.getFirstSelectedOption();
		//System.out.println(e3.getText());
		//List<WebElement> list1 = s2.getAllSelectedOptions();
		//for(WebElement k: list1) {
			
		//System.out.println(k.getText());
		//}
		//s2.deselectAll();
		
		
		
		
		//Thread.sleep(3000);
		
		
	}
	@AfterTest
	
	public void closebrowser() {
		
		driver.quit();
	}
	
}
