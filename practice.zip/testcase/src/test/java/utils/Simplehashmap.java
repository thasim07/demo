package utils;

import java.util.HashMap;
import java.util.Map;

public class Simplehashmap {
	
	public static void main(String[]args) {
		boolean flag=false;
		HashMap<String, Integer> hm=new HashMap<String, Integer>();
		hm.put("key1",10);
		hm.put("key2",24);
		hm.put("key3",56);
		hm.put("key4",17);
		hm.put("key4",20);
		
		System.out.println(hm);
		
		for(Map.Entry<String,Integer> entry:hm.entrySet()) {
			
			if(entry.getValue()<10) {
				
				System.out.println(entry.getKey()+":"+entry.getValue());
				flag=true;
			}
			
		}
		
		if(flag==false) {
			
			System.out.println("There is no value");
		}
	}

}
