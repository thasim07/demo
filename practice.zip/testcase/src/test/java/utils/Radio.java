package utils;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Radio {

	public WebDriver driver;

	@BeforeMethod
	public void openBrowser() throws InterruptedException
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://www.hyrtutorials.com/p/window-handles-practice.html");


	}
	
	@Test
	public void homepage() throws InterruptedException, IOException {
	
		String s = driver.getWindowHandle();
		WebElement e = driver.findElement(By.xpath("//button[@id='newTabsBtn']"));
		e.click();
		System.out.println(s);
	}
	
	@AfterMethod
	
	public void closebrowser() {
		
		driver.quit();
	}
}
