package utils;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Userlogin {
	
	public static HashMap <String, String> logindata(){
		
		HashMap<String, String> hm=new HashMap<String, String>();
		
		hm.put("x", "Admin@admin123");
		hm.put("y", "Agmin@adin13");
		
		return hm;
	}

	public static void main(String[]args) {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize(); 
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		// login as x
		String data = logindata().get("y");
		String[] s = data.split("@");
		driver.findElement(By.name("username")).sendKeys(s[0]);
		driver.findElement(By.name("password")).sendKeys(s[1]);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		// validation
		
		if(driver.getTitle().equals("OrangeHRM")) {
			
			System.out.println("Test passed");
		}
		else
		{
			System.out.println("Test failed");
		}
		
		driver.quit();
		
	}
}
