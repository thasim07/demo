package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class FileOperations {

	@DataProvider(name ="orangehrm")
	public String[][] getdata() throws Throwable{


		File filepath=new File("path");
		FileInputStream fileinput=new FileInputStream(filepath);
		XSSFWorkbook workbook=new XSSFWorkbook();
		XSSFSheet sheet = workbook.getSheetAt(0);
		int numberOfRows = sheet.getPhysicalNumberOfRows();
		int numberOfColumn = sheet.getRow(0).getLastCellNum();

		String[][] data=new String[numberOfRows-1][numberOfColumn];

		for(int i=0;i<numberOfRows;i++) {
			for(int j=0;j<numberOfColumn;j++) {

				DataFormatter dateformat=new DataFormatter();
				data[i][j] = dateformat.formatCellValue(sheet.getRow(i+1).getCell(j));

			}
		}
		workbook.close();
		fileinput.close();
		return data;

	}
	
	
	

}
