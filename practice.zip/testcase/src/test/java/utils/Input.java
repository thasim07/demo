package utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Input {
	
	public WebDriver driver;
	
	@BeforeTest

	public void openbrowser()
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://letcode.in/");
		
	}
	
	@Test
	
	public void inputvalues() throws Exception
	{
		driver.findElement(By.linkText("Work-Space")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
		driver.findElement(By.id("fullName")).sendKeys("Mohamed Thasim");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@value='I am good']")).sendKeys(" boy", Keys.TAB);
		Thread.sleep(3000);
	    String e1 = driver.findElement(By.id("getMe")).getAttribute("value");
	    System.out.println(e1);
		Thread.sleep(3000);
		driver.findElement(By.id("clearMe")).clear();
		Thread.sleep(3000);
		boolean e2 = driver.findElement(By.id("noEdit")).isEnabled();
		System.out.println(e2 +"enable");
		String e3 = driver.findElement(By.id("dontwrite")).getAttribute("readonly");
		System.out.println(e3);
	}
	
	@AfterTest
	
	public void closebrowser()
	
	{
		driver.close();
	}
}
