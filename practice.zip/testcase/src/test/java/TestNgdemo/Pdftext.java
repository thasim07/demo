package TestNgdemo;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.testng.Assert;

public class Pdftext {
	
	public static void main(String[]args) {
		
		try {
			PDDocument document= PDDocument.load(new File("C://Users//Admin//Downloads//Thasim.pdf"));
			
			//numberofpages
			
			int numberOfPages = document.getNumberOfPages();
			System.out.println(numberOfPages);
			Assert.assertEquals(numberOfPages, 3);
			
			//Readtextfrompdf
			
			PDFTextStripper textstripper=new PDFTextStripper();
			String text = textstripper.getText(document);
			System.out.println(text);
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
