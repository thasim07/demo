package TestNgdemo;

import org.testng.annotations.Test;

public class MyFirstProgram {

	@Test
	  public void f() {
		  
		  System.out.println("Hi");
	  }
	  
	  @Test
	  public void f1()
	  {
		  int i=1/3;
		  System.out.println(i);
	  }
}







	