package screenshot;

import org.testng.Assert;
import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class TestClass extends BaseClass {
	
	@Test
	public void amazon() throws InterruptedException
	
	{
		driver.get("https://www.amazon.in/");
		Thread.sleep(3000);
		driver.findElement(By.partialLinkText("Hello, sign in")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("createAccountSubmit")).click();
		Thread.sleep(3000);
		
	}
	
	@Test
	
	public void flipkart() throws InterruptedException {
		
		driver.get("https://www.flipkart.com/");
		Thread.sleep(3000);
		String actualtitle = driver.getTitle();
		String expectedtitile="flipkart";
		System.out.println("Title: " +actualtitle);
		Assert.assertEquals(actualtitle, expectedtitile);
		//driver.findElement(By.xpath("//a[@class='_1_3w1N']")).click();
		Thread.sleep(3000);
		
	}
	
	
	
}
