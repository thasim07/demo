package screenshot;

import org.testng.ITestResult;
import org.testng.ITestListener;

public class ITestListenerr extends BaseClass implements ITestListener
{

	@Override
	public void onTestFailure(ITestResult result) {
		
		capturescreenshot(result.getName()+ ".png");
	}

	
}
