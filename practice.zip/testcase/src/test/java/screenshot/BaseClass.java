package screenshot;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass{

	public static WebDriver driver;
	@BeforeTest
	
	public void openbrowser() {
		
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	
	@AfterTest
   public void closebrowser()
   {
	   driver.quit();
   }
	
	public void capturescreenshot(String filename) {
		
		TakesScreenshot s =(TakesScreenshot)driver;
		File temp = s.getScreenshotAs(OutputType.FILE);
		File perm = new File("./MyScreenshot/pic" + filename);
		try {
			FileUtils.copyFile(temp,perm);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Screeshot successfully saved");
	}
}
