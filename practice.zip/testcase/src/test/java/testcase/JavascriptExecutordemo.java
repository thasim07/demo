package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class JavascriptExecutordemo {
	
	public static void main(String[] args) throws InterruptedException {
		
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver= new ChromeDriver();
		
	    driver.get("https://www.youtube.com/");
		
		driver.manage().window().maximize();
		
		JavascriptExecutor jse=(JavascriptExecutor)driver;
		
		jse.executeScript("window.location='https://www.amazon.in/'");
		
		Thread.sleep(7000);
		
		//jse.executeScript("window.scrollBy(0,3000)");
		
		//Thread.sleep(7000);
		
		//jse.executeScript("window.scrollBy(0,-3000)");
		
		//Thread.sleep(7000);
		
		jse.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		
		Thread.sleep(7000);
		
		jse.executeScript("window.scrollBy(0,-document.body.scrollHeight)");
		
		
		
		//WebElement e = driver.findElement(By.name("q"));
		
		//jse.executeScript("arguments[0].style.border='4px solid red'",e);
		
		//WebElement e1 = driver.findElement(By.linkText("Images"));
		
		//jse.executeScript("arguments[0].style.backgroundColor='rgb(0,200,0)'", e1);
		
		//Thread.sleep(5000);
		
		//WebElement e2 = driver.findElement(By.linkText("Gmail"));
		
		//jse.executeScript("arguments[0].click()",e2);
		
		//Thread.sleep(5000);
		
		//jse.executeScript("history.go(0)");
		
		
		
		Thread.sleep(5000);
		
		driver.close();
		
	}

}
