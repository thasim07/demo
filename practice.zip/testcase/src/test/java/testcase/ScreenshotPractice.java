package testcase;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ScreenshotPractice {

	
	public static void main(String[] args) throws Exception{
		
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver=new ChromeDriver();
		
		driver.navigate().to("https://www.google.com/");
		
		driver.manage().window().maximize();
		
		Thread.sleep(4000);
		
		WebElement e = driver.findElement(By.name("q"));
		
		e.sendKeys("vellore fort" + Keys.ENTER);
		
		Thread.sleep(5000);
		
		TakesScreenshot tks=(TakesScreenshot) driver;
		
		File temp=tks.getScreenshotAs(OutputType.FILE);
		
		File perm=new File("./MyScreenshot/Vellorefort.jpg");
		
		FileUtils.copyFile(temp, perm);
		
		driver.close();
		
	}
	
	}
	
	
	
