package testcase;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Add {

	/* public static void main(String[] args) throws InterruptedException, AWTException {
	        WebDriverManager.chromedriver().setup();
	        WebDriver driver = new ChromeDriver();
	        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	        driver.manage().window().maximize();
	        Thread.sleep(5000);
	        driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("Admin");
	        driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("admin123");
	        driver.findElement(By.xpath("//button[@type='submit']")).click();
	        Thread.sleep(5000);
	        driver.findElement(By.xpath("//span[normalize-space()='My Info']")).click();
	        Thread.sleep(5000);
	WebElement ee= driver.findElement(By.xpath("//button[normalize-space()='Add']"));
	        Thread.sleep(5000);
	        JavascriptExecutor js = (JavascriptExecutor)driver;
	        js.executeScript("arguments[0].scrollIntoView();",ee);
	        ee.click();
	        Thread.sleep(5000);
	        driver.findElement(By.xpath("//div[@class='oxd-file-input-div']")).click();
	        Robot robot=new Robot();
	        robot.delay(2000);
	        StringSelection stringSelection=new StringSelection("C:\\Users\\Admin\\Downloads\\thasim\\Resume.docx");
	        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

	        robot.keyPress(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_V);
	        robot.delay(2000);
	        robot.keyRelease(KeyEvent.VK_CONTROL);
	        robot.keyRelease(KeyEvent.VK_V);
	        robot.delay(2000);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	        //driver.quit();
}*/

	public static void main(String[] args) throws InterruptedException { 
		//Set system properties for geckodriver System.setProperty("webdriver.gecko.driver", "Path_of_the_driver");
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		String URL = "https://the-internet.herokuapp.com/drag_and_drop";
		driver.get(URL);
		// It is always advisable to Maximize the window before performing DragNDrop action driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		//Actions class method to drag and drop 
		Actions builder = new Actions(driver);
		WebElement from = driver.findElement(By.xpath("//header[text()='A']"));
		WebElement to = driver.findElement(By.xpath("//header[text()='B']")); 
		//Perform drag and drop
		builder.dragAndDrop(from, to).build().perform();
		//verify text changed in to 'Drop here' box 
		String textTo = to.getText();
		if(textTo.equals("Dropped!")) {
			System.out.println("PASS: File is dropped to target as expected");
		}else {
			System.out.println("FAIL: File couldn't be dropped to target as expected");
		}
		driver.close();
	} 
}