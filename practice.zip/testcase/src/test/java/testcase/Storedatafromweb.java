package testcase;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FilterWriter;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Storedatafromweb {
	
	public WebDriver driver;
	
	@BeforeTest
	public void openbrowser() {
		
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://timesofindia.indiatimes.com/?from=mdr");
		
	}
	
	@Test
	
	public void savedatainexcel() throws Exception {
		
		WebElement e = driver.findElement(By.xpath("(//a[text()='ICC World Cup 2023 Schedule'])[1]"));
		String text = e.getText();
		
	/*	try {
			FileOutputStream fs= new FileOutputStream("C:\\Users\\Admin\\Downloads\\demo.xlsx");
			XSSFWorkbook wb=new XSSFWorkbook();
			XSSFSheet sheet = wb.createSheet("thasim");
			XSSFRow row = sheet.createRow(0);
			XSSFCell cell = row.createCell(0);
			cell.setCellValue(text);
			wb.write(fs);
			wb.close();
			fs.close();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		
		try {
			FileWriter f=new FileWriter("C:\\Users\\Admin\\Downloads\\demo.txt");
			BufferedWriter bw=new BufferedWriter(f);
			bw.write(text+"a");
			bw.close();
	
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	@AfterTest
	
	
	public void teardown() {
		
		driver.quit();
	}

}
