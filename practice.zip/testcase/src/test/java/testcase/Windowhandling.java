package testcase;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Windowhandling {

public static void main(String[] args) throws Exception {
		
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.hyrtutorials.com/p/window-handles-practice.html");
		
		driver.manage().window().maximize();
		
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		String parentwindow = driver.getWindowHandle();
		WebElement st = driver.findElement(By.id("newTabBtn"));
		st.click();
		System.out.println(parentwindow);
		Set<String> w = driver.getWindowHandles();
		for(String k: w) {
			
			if(!k.equals(parentwindow)) {
				driver.switchTo().window(k);
			    WebElement el1 = driver.findElement(By.xpath("//button[@id='alertBox']"));
			    el1.click();
			    Alert a =driver.switchTo().alert();   
			    a.accept();
				driver.close();
			}
		}
		driver.switchTo().window(parentwindow);
		Thread.sleep(3000);
		
		driver.close();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}

}
		
		/*Set<String> allwindows = driver.getWindowHandles();
		
		for(String k : allwindows)
		{
			if(!k.equals(parentwindow))
			{
				driver.switchTo().window(k);
				WebElement ele1 = driver.findElement(By.id("alertBox"));
				ele1.click();
				Alert a = driver.switchTo().alert();
				Thread.sleep(7000);
				a.accept();
				
				Thread.sleep(7000);
				driver.close();
				
			}
		}     

                Thread.sleep(10000);

                driver.close();
                
    }
   } */


