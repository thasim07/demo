package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MyFirstProgram {

public static void main(String[] args) throws Exception {
		
		WebDriverManager.chromedriver().setup();
		
		// TO Launch the browser
		
		WebDriver driver = new ChromeDriver();
		
		// To launch a URL 
		
		driver.get("https://www.google.com/");
		
		// TO Maximize the browser
		
		driver.manage().window().maximize();
		
		WebElement e=driver.findElement(By.name("q"));
		
		e.sendKeys("vellore fort");
		
		String t = e.getAttribute("value");
		
		System.out.println(t);
		
		
		Thread.sleep(5000);
		
		//To close the current browser
		
		driver.close();
}
}
