package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Gettext {
	
	@Test
	
	public void text() throws Exception{
		
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver=new ChromeDriver();
		
		driver.navigate().to("https://www.qafox.com/selenium/selenium-practice/");
		
		driver.manage().window().maximize();
		
		Thread.sleep(5000);
		
		WebElement e =driver.findElement(By.xpath("//h1[text()='Real time Websites to practice Selenium']"));
		
		
		String t = e.getAttribute("innerText");
		String t2 = e.getAttribute("itemprop");
				
		System.out.println(t);
		System.out.println(t2);
		
		Thread.sleep(4000);
	
		
		//String t = e.getText();
		
		
		//System.out.println(t);
		
		
	    driver.close();
		
		
		
		
		
	}

}
