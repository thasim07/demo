package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MySecondProgram {

	public static void main(String[] args) throws Exception {
		
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.co.in");
		
		driver.manage().window().maximize();
		
		Thread.sleep(6000);
		
		WebElement e = driver.findElement(By.name("q"));
		
		e.sendKeys("Mohamed Thasim" + Keys.ENTER);
		
		Thread.sleep(5000);
		
		WebElement e1 =driver.findElement(By.linkText("Images"));
		
		e1.click();
		
		WebElement e2 =driver.findElement(By.xpath("//img[@alt='Mohamed Thasim (@thasim_mohamed) / Twitter']"));
		
		e2.click();
		
		
		System.out.println("Src attribute is: "+ e2.getAttribute("src"));
		
		
		Thread.sleep(19000);
		
		driver.close();
	}
}
