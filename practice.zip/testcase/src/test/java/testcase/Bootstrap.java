package testcase;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Bootstrap {

	public static void main(String[] args) {
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("http://seleniumpractise.blogspot.com/2016/08/bootstrap-dropdown-example-for-selenium.html");
		
		//locating the dropdown and click
		WebElement e=driver.findElement(By.id("menu1"));
		e.click();
		
		//store the webelements in list of webelements. In this, options are stored in 'a' tag 
		//html, css, javascript, about us
		List<WebElement> e1=driver.findElements(By.xpath("//ul[@role='menu']//li//a"));
		
		//iterating using enhanced for loop
		for(WebElement k: e1) {
			
			String text = k.getText();  
			if(text.equals("HTML")) {
				
				System.out.println(text);
			}
		}
		
		driver.quit();
		
		
		
	}
}
