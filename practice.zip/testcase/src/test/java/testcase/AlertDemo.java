package testcase;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AlertDemo {

	public static void main(String[] args) throws Exception {
		
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver=new ChromeDriver();
		
		driver.navigate().to("https://demoqa.com/alerts");
		
		driver.manage().window().maximize();
		
		
		Thread.sleep(5000);
		
		/*WebElement e= driver.findElement(By.id("alertButton"));
		
		e.click();
		
		
		Alert a = driver.switchTo().alert();
		
		Thread.sleep(5000);
		
		a.accept();
		
		
		WebElement e1=driver.findElement(By.id("confirmButton"));
		
		e1.click();
		
		Alert a1 = driver.switchTo().alert();
		
		Thread.sleep(5000);
		
		a1.dismiss();*/
		
		WebElement e2=driver.findElement(By.xpath("//button[@id='promtButton']"));
		
		e2.click();
		
		
		Alert a2 = driver.switchTo().alert();
		
		Thread.sleep(5000);
		
		a2.accept();
		
		Thread.sleep(5000);
		
		driver.close();
	}
}
