package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonAccountCreation {

	@Test

public void amazoncred() throws Exception{
	
	 WebDriverManager.chromedriver().setup();
	 
	 WebDriver driver=new ChromeDriver();
	 
	 driver.get("https://www.amazon.in/");
	 
	 driver.manage().window().maximize();
	 
	 Thread.sleep(5000);
	 
	 WebElement e = driver.findElement(By.partialLinkText("Hello, sign in"));
	 
	 e.click();
	 
	 Thread.sleep(4000);
	 
	 WebElement e1 = driver.findElement(By.id("createAccountSubmit"));
	 
	 e1.click();
	 
	 Thread.sleep(6000);
	 
	 WebElement e2=driver.findElement(By.name("customerName"));
	 
	 e2.sendKeys("Thasim");
	 
	 Thread.sleep(6000);
	 
     WebElement e3 = driver.findElement(By.id("ap_phone_number"));
	 
	 e3.sendKeys("8807595797");
	 
	 
	 WebElement e4= driver.findElement(By.id("ap_password"));
	 
	 e4.sendKeys("Selenium@123" + Keys.ENTER);
	 
	 Thread.sleep(6000);
	 
	 driver.close();
}
}
