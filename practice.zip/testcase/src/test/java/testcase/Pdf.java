package testcase;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class Pdf {

	public static void main(String []args) {
		
		String filepath="C://Users//Admin//Downloads//Thasim.pdf";
		extractfrompdf(filepath);
		
	}
	
	public static void extractfrompdf(String filepath) {
		
		try {
			PDDocument document=PDDocument.load(new File(filepath));
			int numberOfPages = document.getNumberOfPages();
			System.out.println(numberOfPages);
			
			PDFTextStripper textstripper=new PDFTextStripper();
			String pdftext = textstripper.getText(document);
			System.out.println(pdftext);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}
