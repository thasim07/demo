package travel;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Form {
	
	public static WebDriver driver;
	
	@BeforeTest

	public void setup() {
		
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	
	@Test
	
	public void formfilling() {
		
		driver.get("https://letcode.in/forms");
		driver.findElement(By.xpath("//input[@id='firstname']")).sendKeys("Mohamed");
		driver.findElement(By.xpath("//input[@id='lasttname']")).sendKeys("Thasim");
		WebElement e = driver.findElement(By.xpath("//input[@id='email']"));
		e.clear();
		e.sendKeys("mohamedthasim07@gmail.com");
		WebElement e1 = driver.findElement(By.xpath("//option[@value='1']/ancestor::select"));
		e1.click();
		Select s=new Select(e1);
		s.selectByVisibleText("India (+91)");
		
		driver.findElement(By.xpath("//input[@id='Phno']")).sendKeys("8807595797");
		driver.findElement(By.xpath("//input[@id='Addl1']")).sendKeys("No.2 thopphu street");
		driver.findElement(By.xpath("//input[@id='Addl2']")).sendKeys("Acharapakkam");
		driver.findElement(By.xpath("//input[@id='state']")).sendKeys("Tamilnadu");
		driver.findElement(By.xpath("//input[@id='postalcode']")).sendKeys("603301");
		
		WebElement e2 = driver.findElement(By.xpath("//option[@value='Afghanistan']/ancestor::select"));
		e2.click();
		Select s1=new Select(e2);
		s1.selectByVisibleText("India");
		
		driver.findElement(By.xpath("//input[@id='Date']")).sendKeys("27061998");
		
		driver.findElement(By.xpath("//input[@id='male']")).click();
		
		driver.findElement(By.xpath("//input[@type='checkbox']")).click();
		
		driver.findElement(By.xpath("//input[@type='submit']")).click();
			
	}
	
	@Test
	
	public void alert() {
		
		driver.get("https://letcode.in/waits");
		driver.findElement(By.xpath("//button[@id='accept']")).click();
		
		WebDriverWait wait=new WebDriverWait(driver, 20);
		Alert until = wait.until(ExpectedConditions.alertIsPresent());
		until.accept();
		
	}
	
	@AfterTest
	
	public void closebrowser() {
		
		driver.close();
	}
}
