package travel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Hashmapp {
	
	public static void main(String[]args) throws IOException {
		
		//read data from excel
		
		try {
			File f= new File("C:\\Users\\Admin\\Downloads\\demo.xlsx");
			FileInputStream ip= new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook();
			XSSFSheet sheet = wb.getSheetAt(0);
			int numberOfRows = sheet.getLastRowNum();
			int numberofcolm = sheet.getRow(0).getLastCellNum();
			
			for(int i=1;i<numberOfRows;i++) {
				for(int j=0;j<numberofcolm;j++) {
					
					DataFormatter df=new DataFormatter();
					System.out.println(df.formatCellValue(sheet.getRow(i).getCell(j)));
				}
				
				System.out.println();
			}
			wb.close();
			ip.close();
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
}
