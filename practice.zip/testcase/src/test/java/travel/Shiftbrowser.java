package travel;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Shiftbrowser {

	public WebDriver chromeDriver;
	public WebDriver edgeDriver;

	@BeforeTest
	public void openbrowser() {

		WebDriverManager.chromedriver().setup();
		WebDriverManager.edgedriver().setup();
		chromeDriver=new ChromeDriver();
		chromeDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@Test

	public void changebrowser() throws Exception {

		chromeDriver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		Thread.sleep(3000);

		WebElement e2=chromeDriver.findElement(By.name("username"));
		e2.sendKeys("Admin");
		
		WebElement e3=chromeDriver.findElement(By.name("password"));
		e3.sendKeys("admin123");
		
		Thread.sleep(3000);
		
		WebElement e5=chromeDriver.findElement(By.xpath("//button[@type='submit']"));
		e5.click();
		
		Thread.sleep(3000);

		edgeDriver= new EdgeDriver();
		
		edgeDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		edgeDriver.get(chromeDriver.getCurrentUrl());
		Thread.sleep(4000);
		WebElement e4=chromeDriver.findElement(By.linkText("OrangeHRM, Inc"));
		Thread.sleep(4000);
		e4.click();
	}


	@AfterTest

	public void closebrowser() {

		chromeDriver.quit();
		edgeDriver.quit();
	}
}
