package travel;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;



public class Travelagency {

	public static WebDriver driver;
	
	@BeforeTest
	public static void openbrowser() {
		
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://blazedemo.com/index.php");
	}
	
	@Test(priority=1)
	
	public void title() {
		
	  String Expectedtitle="Welcome to the Simple Travel Agency!";
	  String actualtitle = driver.getTitle();
	  if(Expectedtitle.equals(actualtitle)) {
		  
		  System.out.println("Given title is correct");
		  
	  }
	  else
	  {
		  System.out.println("Given title is in-correct");
	  }
	}
	
	@Test(priority=2)
	
	public void clickonlink() throws InterruptedException {
		
		driver.findElement(By.linkText("destination of the week! The Beach!")).click();
		
		Thread.sleep(4000);
		String actualurl = driver.getCurrentUrl();
		Assert.assertTrue(actualurl.contains("vacation"));
		
		driver.navigate().back();
	}
	
	@Test(priority=3)
	
	public void purchaseticket() throws InterruptedException
	{
		
		WebElement e = driver.findElement(By.xpath("//select[@class='form-inline' and @name='fromPort'] "));
		e.click();
		
		Select s=new Select(e);
		
		s.selectByIndex(5);
		
		WebElement e1 = driver.findElement(By.xpath("//select[@class='form-inline' and @name='toPort'] "));
		
		e1.click();
		
		Select s1=new Select(e1);
		s1.selectByIndex(2);
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		
		driver.findElement(By.xpath("//td[text()='$432.98']//following::tr/td/input")).click();
		
		boolean enabled = driver.findElement(By.xpath("//p[text()='Total Cost: ']")).isEnabled();
		System.out.println("Total cost: "+ enabled);
		
		driver.findElement(By.xpath("//input[@value='Purchase Flight']")).click();
		
		WebElement id = driver.findElement(By.xpath("//td[text()='Id']/following::td"));
		
		System.out.println("purchase id: "+ id.getText());
		
		
		}
	
	
	
	@AfterTest
	public void closebrowser() {
		
		driver.close();
	}
}
