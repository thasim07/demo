package inheritancedemo;

public class Fatherhouse extends Grandfatherhouse{

	public void interceptorbike()
	{
		System.out.println("Father has interceptor bike ");
	}
}
