package inheritancedemo;

public class sonhouse extends Fatherhouse{

	public void ktmbike()
	{
		System.out.println("son has ktm bike ");
	}
	
	public static void main(String[] args) {
		
		sonhouse s=new sonhouse();
		s.ktmbike();
		s.interceptorbike();
		s.bulletbike();
		
		Daughterhouse d=new Daughterhouse();
		d.bulletbike();
	
		
	}
}
