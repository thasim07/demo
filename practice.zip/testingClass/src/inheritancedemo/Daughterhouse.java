package inheritancedemo;

public class Daughterhouse extends Fatherhouse{
	
	public void scootybike()
	{
		System.out.println("daughter has scooty bike ");
	}
	
	
}
