package inheritancedemo;

public class Grandfatherhouse {

	public void bulletbike()
	{
		System.out.println("Grandfather has bullet bike ");
	}
}
