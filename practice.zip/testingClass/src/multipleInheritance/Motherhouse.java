package multipleInheritance;

public interface Motherhouse {

	public void scooter();
}
