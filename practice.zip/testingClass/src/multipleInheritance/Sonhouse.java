package multipleInheritance;

public class Sonhouse implements Fatherhouse, Motherhouse{

	public void mt15() {
		
		System.out.println("son has mt 15 bike");
	
	}
public void rx100(){
	System.out.println("father has rx100 bike");
}

public void scooter()
{
	System.out.println("they have scooter");
}

public static void main(String[] args) {
	
	Sonhouse s=new Sonhouse();
	s.mt15();
	s.rx100();
	s.scooter();
	
}

}
