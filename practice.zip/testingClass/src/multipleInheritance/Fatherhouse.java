package multipleInheritance;

public interface Fatherhouse {

public void rx100();

public void scooter();
}
