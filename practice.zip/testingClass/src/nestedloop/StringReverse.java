package nestedloop;

public class StringReverse {

	String s="dad";
	String u="";
	
	public void reverseofstring() {
		
		char []c=s.toCharArray();
		
		for(int i=s.length()-1;i>=0;i--) {
			
			u=u+c[i];
		}
		System.out.println("Reverse of string is: "+ u);
		
		if(s.equals(u)) {
			
			System.out.println("It is a palindrome:" +u);
			
		}
		else
			
		{
			System.out.println("It is not a palindrome" +u);
		}
	}
	
	public static void main(String[] args) {
		
		StringReverse s= new StringReverse();
		s.reverseofstring();
	}
}
