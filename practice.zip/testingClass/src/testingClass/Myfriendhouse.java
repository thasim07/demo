package testingClass;

public class Myfriendhouse {

	private int amount =10000;
	
	public int getthing() {
		
		return amount;
	}
	
	public void setthing(int la) {
		
		amount = la;
	}
}
	
