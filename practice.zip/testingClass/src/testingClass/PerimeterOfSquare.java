package testingClass;

public class PerimeterOfSquare {
	
    int a=5;
    
    public void square() 
    {
    	System.out.println("Perimeter of Square is: ");
    	System.out.println(4*a);
    	
    }
    public static void main(String[] args) 
    {
    	
		PerimeterOfSquare p=new PerimeterOfSquare();
		p.square();
	}
}
