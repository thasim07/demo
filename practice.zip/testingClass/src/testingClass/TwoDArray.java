package testingClass;

public class TwoDArray {

	int arr[]= {11,33,44,55,66,77};
	
	int tarr[][]={
			{11,33,44},
			{55,66,77,77,88},
			{88,99,22} 
			};
	
	public void array()
	{
	
		//System.out.println(tarr.length);
		//System.out.println(tarr[1][5]);
		//System.out.println(tarr[1].length);
		System.out.println("Iterating 2d Array");
		
		/*for(int row=0;row<=2;row++)
		{
			for(int col=0;col<=2;col++)
			{
				
				System.out.print(tarr[row][col] + " ");
			}
			System.out.println();
		}*/
		
		/*for(int k:arr)
		{
			System.out.println(k);
		}
		
		for(int k[]:tarr)
		{
			for(int m:k)
			{
				System.out.print(m +" ");
			}
			System.out.println();
		}*/
		
		for(int row=0;row<=tarr.length;row++)
		{
			for(int col=0;col<=tarr[row].length;col++)
			{
				System.out.print(tarr[row][col] + " ");
				
			}
			System.out.println();
		}
		System.out.print("length of the array: " + tarr[1].length);
	}
	
	public static void main(String[] args) {
		
		TwoDArray t= new TwoDArray();
		t.array();
		
	}
	
}
