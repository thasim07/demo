package testingClass;

import java.util.HashSet;

public class RemoveDuplicatesFromArray {
    public static void main(String[] args) {
        int[] a = {1,3,3,4};

        HashSet<Integer> uniqueElements = new HashSet<>();
        HashSet<Integer> duplicateElements = new HashSet<>();

        for (int num : a) {
            if (!uniqueElements.add(num)) {
                // The number is a duplicate
                duplicateElements.add(num);
            }
        }

        System.out.println("Duplicate(s) in the array:");
        for (int duplicate : duplicateElements) {
            System.out.print(duplicate + " ");
        }
        System.out.println();

        int[] newArray = new int[a.length - duplicateElements.size()];
        int index = 0;
        for (int num : a) {
            if (!duplicateElements.contains(num)) {
                newArray[index++] = num;
            }
        }

        System.out.println("Array after removing duplicates:");
        for (int num : newArray) {
            System.out.print(num + " ");
        }
    }
}

