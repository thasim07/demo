package testingClass;
/*WAP to remove special characters/alpha and sum up the numbers. 

Input: "Oranium65kweecfh423asdndcf32qre4&^&^%$sdjhfc34623"*/

public class StringDemo {

	String a = "zeruma maadu maadu eruma";
    
    
    public void string() {
    	
    	int[]count= new int[256];
    	for(int i=0;i<a.length();i++) 
    	{
    		
    		count[a.charAt(i)]++;
    	}
    	for(int i=0;i<count.length;i++) {
    		if(count[i]!=0) {
    			System.out.println((char) i + ": " + count[i]);
        }
    	}
    }
	public static void main(String[] args) {
		
		StringDemo s1=new StringDemo();
		s1.string();
	}
}
