package testingClass;

public class PerimeterOfRectangle {
	
	int l=7;
	double w=12.5;
	
	public void rectangle() {
		
		System.out.println("Perimeter of Rectangle is: ");
		System.out.println(2*(l+w));
		
	}
	
	public static void main(String[] args) {
		
		PerimeterOfRectangle p=new PerimeterOfRectangle();
		p.rectangle();
	}

}
