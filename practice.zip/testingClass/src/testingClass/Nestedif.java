package testingClass;

public class Nestedif {

	int a=35;
	
	public void studentMarks()
	{
		if(a>=35)
		{
			if(a>=60) 
			{
			System.out.println("Scored First class mark");
			}
			else
			{
			System.out.println("pass");
			}
			
		}
		else
		{
			System.out.println("Failed");
		}
	    
		
		
	}
	
	public static void main(String[] args) {
		
		Nestedif n=new Nestedif();
		n.studentMarks();
	}
}
