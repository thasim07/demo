package testingClass;

public class AreaOfTriangle {
	
	double b=75;
	double h=67;
	
	public void triangle()
	{
		System.out.println("Area of Triangle is: ");
		System.out.println(b*h/2);
	}
	
	public static void main(String[] args) {
		
		AreaOfTriangle a= new AreaOfTriangle();
		a.triangle();
	}
	
	

}
