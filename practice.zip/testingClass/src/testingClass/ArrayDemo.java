package testingClass;

public class ArrayDemo {

	String arr[]= {"ws","ww"};
	
	public void arrayclass()
	{
		System.out.println(arr[1]);
		
	}
	
	public static void main(String[] args) {
		
		ArrayDemo a=new ArrayDemo();
		a.arrayclass();
	}
}
