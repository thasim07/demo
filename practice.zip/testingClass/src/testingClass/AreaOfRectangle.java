package testingClass;

public class AreaOfRectangle {
	
	int l=80;
	int w=30;
	
	public void rectangle()
	{
		System.out.println("Area of Rectangle  is: ");
		System.out.println(l*w);
	}
	
	public static void main(String[] args) {
		
		AreaOfRectangle a= new AreaOfRectangle();
		a.rectangle();
	}

}
