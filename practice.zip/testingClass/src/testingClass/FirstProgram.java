package testingClass;

public class FirstProgram {

	int var1=2;
	int var2=3;
	
	public void addnumbers()
	
	{
		System.out.println(var1+var2);
	}
	
	public static void main(String[]args)
	{
		FirstProgram obj=new FirstProgram();
		obj.addnumbers();
		
	}
}


