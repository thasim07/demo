package testingClass;

public class Myhouse {

	public static void main(String[] args) {
		
		Myfriendhouse m=new Myfriendhouse();
		
		System.out.println(m.getthing());
		
		m.setthing(50000);
		
		System.out.println(m.getthing());
	}
}
