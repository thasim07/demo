package testingClass;

public class MethodDemo {

	int a=12;
	int b=4;
	
	public void addnumbers() {
		
		System.out.println("addition is : "+ (a+b));
	}
	
	public void subnumbers(int a, int b) {
		
		System.out.println("subtraction is: " +(a-b));
	}
	
	public int multiplynumbers() {
		
		return a*b;
	}
	
	public int dividenumbers(int a, int b) {
		
		return a/b;
	}
	
	public static void main(String[] args) {
		
		MethodDemo m=new MethodDemo();
		m.addnumbers();
		m.subnumbers(2, 3);
		System.out.println("multiply is: "+ m.multiplynumbers());
		System.out.println("Divided is: "+ m.dividenumbers(10, 2));
	}
}
