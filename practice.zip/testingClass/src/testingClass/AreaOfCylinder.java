package testingClass;

public class AreaOfCylinder
{
	
	double pi=3.14159;
	int r=2;
	int h=4;
	
	public void cyclinder()
	{
		System.out.println("Area of Cylinder is: ");
		System.out.println(2*pi*r*h+2*pi*r*r);
		
	}
	
	public static void main(String[] args) {
		
		AreaOfCylinder a =new AreaOfCylinder();
		a.cyclinder();
	}

}
