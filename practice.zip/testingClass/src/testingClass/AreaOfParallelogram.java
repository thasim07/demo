package testingClass;

public class AreaOfParallelogram {
	
	int b=57;
	int h=78;
	
	public void parallelogram()
	{
		System.out.println("Area of Parallelogram is: ");
		System.out.println(b*h);
	}
	
	public static void main(String[] args) {
		
		AreaOfParallelogram a= new AreaOfParallelogram();
		a.parallelogram();
	}

}
