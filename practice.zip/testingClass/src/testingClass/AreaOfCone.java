package testingClass;

public class AreaOfCone {
	
	double pi=3.14159;
	int r=4;
	int h=7;
	double l=8.06225775;
	
	public void cone() 
	{
		System.out.println("Area of cone is: ");
		System.out.println(pi*r*l+pi*r*r);
		
	}
	
	public static void main(String[] args) {
		
		AreaOfCone a= new AreaOfCone();
		a.cone();
	}

}
