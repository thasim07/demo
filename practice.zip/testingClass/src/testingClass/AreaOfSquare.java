package testingClass;

public class AreaOfSquare {
	
	int num1= 100;
	
	public void square() 
	
	{
		System.out.println(num1*num1);
	}
	
	public static void main(String[] args) 
	
	{
		AreaOfSquare a = new AreaOfSquare();
		a.square();
	}
	

}
