package testingClass;

public class ControlStatements {

	int a=34;
	
	
	public void oddEven() {
		
		if(a%2==0)
		{
		 System.out.println("Number is even number");
		}
		else
		{
		System.out.println("Number is odd number");
		}
		
	}
	
	public static void main(String[] args) {
		
		ControlStatements c=new ControlStatements();
		c.oddEven();
	}
}
