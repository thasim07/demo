package testingClass;

public class UsingOperator {

	int var1=8;
	int var2=7;
	
	public void operator()
	{
		/*System.out.println(var1+var2);
		System.out.println(var1-var2);
		System.out.println(var1*var2);
		System.out.println(var1/var2);
		System.out.println(var1%var2); */ //arithmetic operator
		
		/*System.out.println(var1<var2); //f
		System.out.println(var1>var2); //t
		System.out.println(var1<=var2);//f
		System.out.println(var1>=var2);//t
		System.out.println(var1==var2);//f
		System.out.println(var1!=var2);*///t relational
		
		/*System.out.println((var1>var2)&&(var1<var2));//f
		System.out.println((var1<var2)&&(var1<var2));//f
		System.out.println((var1>var2)&&(var1>var2));//t
		System.out.println((var1>=var2)&&(var1<=var2));//f
		System.out.println((var1==var2)&&(var1!=var2));*///f logical&&
		
		/*System.out.println((var1>var2)||(var1<var2)); //t
		System.out.println((var1<var2)||(var1<var2));  //f
		System.out.println((var1>var2)||(var1>var2));  //t
		System.out.println((var1>=var2)||(var1<=var2)); //t
		System.out.println((var1==var2)||(var1!=var2)); *///t logical||
		
		/*System.out.println(!(var1<var2)); //t
		System.out.println(!(var1>var2));*/ //f  logical not
		
		/*System.out.println(var1++);
		System.out.println(--var1);
		System.out.println(++var1);
		System.out.println(var1--);
		System.out.println(var1);  increment/decrement*/
		
	}
	
	public static void main(String[] args) {
		
		UsingOperator u=new UsingOperator();
		u.operator();
	}
}
