package testingClass;


public class Exceptiondemo {

	
	public void dividenumbers() {
		
		System.out.println("Welcome To Maths");
		
		for(int iphone=3; iphone>=0; iphone--)
		{
			System.out.println(iphone);
			if(iphone==0)
			{
				throw new StringIndexOutOfBoundsException("out of stock");
			}
			
		}
		
		System.out.println("Good By to Maths");
	}

	
	
	public static void main(String[] args) {
		
		Exceptiondemo e = new Exceptiondemo();
		e.dividenumbers();
	}
}
