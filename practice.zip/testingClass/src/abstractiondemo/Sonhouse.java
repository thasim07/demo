package abstractiondemo;

public class Sonhouse extends Fatherhouse{
	

	public void tvs() {
		
		System.out.println("son has tvs bike");
      }
	
	public void audicar() {
		
		System.out.println("this father audi car");
		
	}
	
	public void bmwcar() {
		
		System.out.println("this is father bmw car");
	}
	
	public void tvsjupiter()
	{
		System.out.println("this son tvs jupiter");
	}
	
	public static void main(String[] args) {
		
		Sonhouse s=new Sonhouse();
		s.tvs();
		s.tvsjupiter();
		s.bmwcar();
		s.audicar();
	}
}
