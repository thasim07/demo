package abstractiondemo;

public abstract class Fatherhouse {

public abstract void audicar();

public abstract void bmwcar();

public void tvsjupiter()
{
	System.out.println("this father tvs jupiter");
}
	
}
